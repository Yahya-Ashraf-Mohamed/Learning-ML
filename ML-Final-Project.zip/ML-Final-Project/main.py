import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn import preprocessing
import seaborn as sns
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.metrics import log_loss
from sklearn.metrics import f1_score

# Import the library for SVM Classifier
from sklearn import svm

# Import the library for Logistice regression
from sklearn.linear_model import LogisticRegression

# Import the decision tree model
from sklearn.tree import DecisionTreeClassifier

#from sklearn.metrics import jaccard_similarity_score

#notice: Disable all warnings
import warnings
warnings.filterwarnings('ignore')

if __name__ == '__main__':

    df = pd.read_csv('loan_train.csv')
    print(df.head(),"\n")

    print(df.shape,"\n")

    df['due_date'] = pd.to_datetime(df['due_date'])
    df['effective_date'] = pd.to_datetime(df['effective_date'])
    print(df.head(),"\n")

    print(df['loan_status'].value_counts(),"\n")

    bins = np.linspace(df.Principal.min(), df.Principal.max(), 10)
    g = sns.FacetGrid(df, col="Gender", hue="loan_status", palette="Set1", col_wrap=2)
    g.map(plt.hist, 'Principal', bins=bins, ec="k")

    g.axes[-1].legend()
    plt.show()

    bins = np.linspace(df.age.min(), df.age.max(), 10)
    g = sns.FacetGrid(df, col="Gender", hue="loan_status", palette="Set1", col_wrap=2)
    g.map(plt.hist, 'age', bins=bins, ec="k")

    g.axes[-1].legend()
    plt.show()

    df['dayofweek'] = df['effective_date'].dt.dayofweek
    bins = np.linspace(df.dayofweek.min(), df.dayofweek.max(), 10)
    g = sns.FacetGrid(df, col="Gender", hue="loan_status", palette="Set1", col_wrap=2)
    g.map(plt.hist, 'dayofweek', bins=bins, ec="k")
    g.axes[-1].legend()
    plt.show()

    df['weekend'] = df['dayofweek'].apply(lambda x: 1 if (x > 3) else 0)
    print(df.head(),"\n")

    print(df.groupby(['Gender'])['loan_status'].value_counts(normalize=True),"\n")

    df['Gender'].replace(to_replace=['male', 'female'], value=[0, 1], inplace=True)
    print(df.head(),"\n")

    print(df.groupby(['education'])['loan_status'].value_counts(normalize=True),"\n")

    print(df[['Principal', 'terms', 'age', 'Gender', 'education']].head(),"\n")

    Feature = df[['Principal', 'terms', 'age', 'Gender', 'weekend']]
    Feature = pd.concat([Feature, pd.get_dummies(df['education'])], axis=1)
    Feature.drop(['Master or Above'], axis=1, inplace=True)
    print(Feature.head(),"\n")

    X = Feature
    print(X[0:5],"\n")

    y = df['loan_status'].values
    print(y[0:5],"\n")

    X = preprocessing.StandardScaler().fit(X).transform(X)
    print(X[0:5],"\n")

#=================================================================================================================
                                                # K Nearest Neighbor(KNN)
#==================================================================================================================
    # Train-Test Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

    # Training
    Ks = 15
    mean_acc = np.zeros((Ks - 1))
    std_acc = np.zeros((Ks - 1))
    ConfustionMtx = [];
    for n in range(1, Ks):
        neigh = KNeighborsClassifier(n_neighbors=n).fit(X_train, y_train)
        yhat = neigh.predict(X_test)
        mean_acc[n - 1] = metrics.accuracy_score(y_test, yhat)
        std_acc[n - 1] = np.std(yhat == y_test) / np.sqrt(yhat.shape[0])
    print(mean_acc,"\n")

    plt.plot(range(1, Ks), mean_acc)
    plt.fill_between(range(1, Ks), mean_acc - 1 * std_acc, mean_acc + 1 * std_acc, alpha=0.10)
    plt.legend(('Accuracy ', '+/- 3xstd'))
    plt.ylabel('Accuracy ')
    plt.xlabel('Number of Neighbors (K)')
    plt.tight_layout()
    plt.show()

    print("The best accuracy was with", mean_acc.max(), "with k=", mean_acc.argmax() + 1)

    neigh = KNeighborsClassifier(n_neighbors=mean_acc.argmax() + 1).fit(X_train, y_train)

    print("The best accuracy was with", mean_acc.max(), "with k=", mean_acc.argmax() + 1)

    k = mean_acc.argmax() + 1

    # Train Model and Predict
    loan_knn = KNeighborsClassifier(n_neighbors=k).fit(X_train, y_train)
    print(loan_knn,"\n")

    y_hat = loan_knn.predict(X_test)
    print(y_hat[0:5],"\n")

    print("Train set Accuracy: ", metrics.accuracy_score(y_train, loan_knn.predict(X_train)))
    print("Test set Accuracy: ", metrics.accuracy_score(y_test, y_hat))


    print(classification_report(y_test, yhat))

    #jaccard_similarity_score(y_test, yhat)

    print(f1_score(y_test, yhat, average='weighted'),"\n")

#=========================================================================================================================
#                                                       Decision Tree
#=========================================================================================================================


md = 10
mean_acc = np.zeros((md - 1))
std_acc = np.zeros((md - 1))
ConfustionMx = [];
for n in range(1, md):
    # Train Model and Predict
    loant = DecisionTreeClassifier(criterion="entropy", max_depth=n).fit(X_train, y_train)
    yhat = loant.predict(X_test)
    mean_acc[n - 1] = metrics.accuracy_score(y_test, yhat)

    std_acc[n - 1] = np.std(yhat == y_test) / np.sqrt(yhat.shape[0])

print(mean_acc,"\n")

plt.plot(range(1,md),mean_acc,'r')
plt.fill_between(range(1,md),mean_acc - 1 * std_acc,mean_acc + 1 * std_acc, alpha=0.10)
plt.legend(('Accuracy ', '+/- 3xstd'))
plt.ylabel('Accuracy ')
plt.xlabel('Number of Max Depth')
plt.tight_layout()
plt.show()

#Building the decision tree with max depth of 5
loan_dt = DecisionTreeClassifier(criterion="entropy", max_depth = 5)

# Check the default parameters
loan_dt

# Train the Decision tree model
loan_dt.fit(X_train,y_train)

# Predict using the model
y_hat= loan_dt.predict(X_test)

#Calculating the train and test accuracy
print("Train set Accuracy: ", metrics.accuracy_score(y_train, loan_dt.predict(X_train)))
print("Test set Accuracy: ", metrics.accuracy_score(y_test, y_hat))
#Building the confusion matrix
print (classification_report(y_test, y_hat))

# Calculate the F1 score
print(f1_score(y_test, y_hat, average='weighted'))


# Calculate the jaccard index
#jaccard_similarity_score(y_test, y_hat)


#=================================================================================================================
                                                # Support Vector Machine
#==================================================================================================================

# Build a SVM Classifier with a Radial base Function Kernel
loansvm1 = svm.SVC(kernel='rbf').fit(X_train, y_train)
yhat1 = loansvm1.predict(X_test)
svm_r = metrics.accuracy_score(y_test, yhat1)

# Build a SVM Classifier with a Linear Kernel
loansvm2 = svm.SVC(kernel='linear').fit(X_train, y_train)
yhat2 = loansvm2.predict(X_test)
svm_l = metrics.accuracy_score(y_test, yhat2)

# Build a SVM Classifier with a Polynomial Kernel
loansvm3 = svm.SVC(kernel='poly').fit(X_train, y_train)
yhat3 = loansvm3.predict(X_test)
svm_p = metrics.accuracy_score(y_test, yhat3)

# Build a SVM Classifier with a Sigmoid Kernel
loansvm4 = svm.SVC(kernel='sigmoid').fit(X_train, y_train)
yhat4 = loansvm4.predict(X_test)
svm_s = metrics.accuracy_score(y_test, yhat4)

print(svm_r, svm_l, svm_p, svm_s)

# Find if labels are missing in the SVM models
print("The label missing in the first model with rbf kernel",set(y_test) - set(yhat1))
print("The label missing in the second model with linear",set(y_test) - set(yhat2))
print("The label missing in the third model with polynomial kernel",set(y_test) - set(yhat3))
print("The label missing in the fourth model with sigmoid kernel",set(y_test) - set(yhat4))

# Build and train the SVM Classifier with a linear kernel

loansvm = svm.SVC(kernel='rbf').fit(X_train, y_train)


#Predicting the test values using the SVM model
yhat = loansvm.predict(X_test)
print(yhat [0:5])

print("Train set Accuracy: ", metrics.accuracy_score(y_train, loansvm.predict(X_train)))
print("Test set Accuracy: ", metrics.accuracy_score(y_test, yhat))

print (classification_report(y_test, yhat))

# Calculate the f1 score
print(f1_score(y_test, yhat, average='weighted'))

#Calculate the Jaccard index
#jaccard_similarity_score(y_test, yhat)


#=================================================================================================================
                                                # Logistic Regression
#==================================================================================================================


# Build and train the logestic regression model
loanlr1 = LogisticRegression(C=0.01, solver='liblinear').fit(X_train,y_train)
yhat1 = loanlr1.predict(X_test)
loanlr_a1 = metrics.accuracy_score(y_test, yhat1)

# Build and train the logestic regression model
loanlr2 = LogisticRegression(C=0.01, solver='sag').fit(X_train,y_train)
yhat2 = loanlr2.predict(X_test)
loanlr_a2 = metrics.accuracy_score(y_test, yhat2)

# Build and train the logestic regression model
loanlr3 = LogisticRegression(C=0.01, solver='saga').fit(X_train,y_train)
yhat3 = loanlr3.predict(X_test)
loanlr_a3 = metrics.accuracy_score(y_test, yhat3)

# Build and train the logestic regression model
loanlr4 = LogisticRegression(C=0.01, solver='newton-cg').fit(X_train,y_train)
yhat4 = loanlr4.predict(X_test)
loanlr_a4 = metrics.accuracy_score(y_test, yhat4)

# Build and train the logestic regression model
loanlr5 = LogisticRegression(C=0.01, solver='lbfgs').fit(X_train,y_train)
yhat5 = loanlr5.predict(X_test)
loanlr_a5 = metrics.accuracy_score(y_test, yhat5)


print('LR model with liblinear solver',loanlr_a1)
print('LR model with sag solver',loanlr_a2)
print('LR model with saga solver',loanlr_a3)
print('LR model with newton-cg solver',loanlr_a4)
print('LR model with lbfgs solver',loanlr_a5)

# Find if labels are missing in the models
print("The label missing in the LR model with liblinear solver",set(y_test) - set(yhat1))
print("The label missing in the LR model with sag solver",set(y_test) - set(yhat2))
print("The label missing in the LR model with saga solver",set(y_test) - set(yhat3))
print("The label missing in the LR model with newton-cg solver",set(y_test) - set(yhat4))
print("The label missing in the LR model with lbfgs solver",set(y_test) - set(yhat5))

#Except for the liblinear solver all other model has skipped the lable "collection" from the predicted values. Hence, the best logistic classifier will be the one with a liblinear solver
loanlr = LogisticRegression(C=0.01, solver='liblinear').fit(X_train,y_train)
yhat = loanlr.predict(X_test)

print("Train set Accuracy: ", metrics.accuracy_score(y_train, loanlr.predict(X_train)))
print("Test set Accuracy: ", metrics.accuracy_score(y_test, yhat))
print (classification_report(y_test, yhat))

# Calculate the f1 score
print(f1_score(y_test, yhat, average='weighted'),'\n')

#Calculate the Jaccard index
#jaccard_similarity_score(y_test, yhat)

#=================================================================================================================
                                                # Model Evaluation using Test set
#==================================================================================================================

test_df = pd.read_csv('loan_test.csv')
print(test_df.head(),'\n')

# shape of the test data set
test_df.shape

# Count of the loan status
print(test_df['loan_status'].value_counts(),'\n')

df = test_df

df['due_date'] = pd.to_datetime(df['due_date'])
df['effective_date'] = pd.to_datetime(df['effective_date'])
df['dayofweek'] = df['effective_date'].dt.dayofweek
df['weekend'] = df['dayofweek'].apply(lambda x: 1 if (x>3)  else 0)

df.groupby(['Gender'])['loan_status'].value_counts(normalize=True)
df['Gender'].replace(to_replace=['male','female'], value=[0,1],inplace=True)

df.groupby(['education'])['loan_status'].value_counts(normalize=True)

Feature = df[['Principal','terms','age','Gender','weekend']]
Feature = pd.concat([Feature,pd.get_dummies(df['education'])], axis=1)
Feature.drop(['Master or Above'], axis = 1,inplace=True)

X_test = Feature

y_test = df['loan_status'].values

X_test = preprocessing.StandardScaler().fit(X_test).transform(X_test)

# KNN model testing
yhat_knn = loan_knn.predict(X_test)

# Calculate the f1 score
f1_knn = f1_score(y_test, yhat_knn, average='weighted')

print('f1 score: ',f1_knn)

'''
#Calculate the Jaccard index# Predict using the model
jsc_knn = jaccard_similarity_score(y_test, yhat_knn)
print('Jaccard index: ',jsc_knn)
'''

# Predict using the model
yhat_dt= loan_dt.predict(X_test)

# Calculate the f1 score
f1_dt = f1_score(y_test, yhat_dt, average='weighted')

print('f1 score: ',f1_dt)


'''
#Calculate the Jaccard index# Predict using the model
jsc_dt = jaccard_similarity_score(y_test, yhat_dt)
print('Jaccard index: ',jsc_dt)
'''

# Predict using the model
yhat_lr = loanlr.predict(X_test)

# Calculate the f1 score
f1_lr = f1_score(y_test, yhat_lr, average='weighted')

# Calculate Log loss
yhat_lr_prob = loanlr.predict_proba(X_test)
ll_lr = log_loss(y_test, yhat_lr_prob)

print('f1 score: ',f1_lr)
print('Log Loss: ',ll_lr)

'''
#Calculate the Jaccard index# Predict using the model
jsc_lr = jaccard_similarity_score(y_test, yhat_lr)
print('Jaccard index: ',jsc_lr)
'''

'''
Jaccard = [jsc_knn, jsc_dt, jsc_svm, jsc_lr]
F1_score = [f1_knn, f1_dt, f1_svm, f1_lr]
LogLoss = ['NA', 'NA', 'NA', ll_lr]

df = {'Algorithm': ['KNN', 'Decistion Tree', 'SVM', 'LogisticRegression'], \
      'Jaccard': Jaccard, 'F1-score': F1_score, 'LogLoss': LogLoss}

Report = pd.DataFrame(data=df, columns=['Algorithm', 'Jaccard', 'F1-score', 'LogLoss'], index=None)
print(Report,'\n')
'''